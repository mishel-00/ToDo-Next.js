'use client';

import React, { useState, startTransition } from 'react';
import { DndContext, closestCenter, DragEndEvent } from '@dnd-kit/core';
import { SortableContext, verticalListSortingStrategy } from '@dnd-kit/sortable';
import { useSensors, useSensor, PointerSensor, KeyboardSensor } from '@dnd-kit/core';
import { sortableKeyboardCoordinates } from '@dnd-kit/sortable';
import { modificarStatusTarea, eliminarTarea } from '@/backend/actions/taskActions';

import { Task } from '../types';
import SortableItem from '../SortableItem/sortableItem';

interface ProjectTasksProps {
  tasks: Task[];
  projectId: number;
}

export function ProjectTasks({ tasks: initialTasks, projectId }: ProjectTasksProps) {
  const [tasks, setTasks] = useState<Task[]>(initialTasks);

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates
    })
  );

  const handleDragEnd = async (event: DragEndEvent) => {
    const { active, over } = event;
    if (!over || active.id === over.id) return;

    startTransition(async () => {
      setTasks((prev) => {
        const oldIndex = prev.findIndex((task) => task.id === active.id);
        const newIndex = prev.findIndex((task) => task.id === over.id);
        const updatedTasks = [...prev];
        // Mover la tarea a la nueva posición
        updatedTasks.splice(newIndex, 0, updatedTasks.splice(oldIndex, 1)[0]);
        return updatedTasks;
      });

      try {
        await modificarStatusTarea(active.id, over.id);
      } catch (error) {
        console.error('Error al modificar el estado de la tarea:', error);
        // Podrías revertir el estado si falla la actualización
        setTasks(initialTasks);
      }
    });
  };

  const handleDeleteTask = async (taskId: number) => {
    try {
      await eliminarTarea(taskId);
      setTasks((prev) => prev.filter((task) => task.id !== taskId));
    } catch (error) {
      console.error('Error al eliminar la tarea:', error);
    }
  };

  return (
    <DndContext
      sensors={sensors}
      collisionDetection={closestCenter}
      onDragEnd={handleDragEnd}
    >
      <SortableContext
        items={tasks.map((task) => task.id)}
        strategy={verticalListSortingStrategy}
      >
        <div className="flex flex-col gap-4">
          {tasks.map((task) => (
            <SortableItem
              key={task.id}
              id={task.id}
              task={task}
              containerId={task.status}
              onDelete={handleDeleteTask}
            />
          ))}
        </div>
      </SortableContext>
    </DndContext>
  );
}





